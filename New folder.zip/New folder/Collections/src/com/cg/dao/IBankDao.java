package com.cg.dao;

import com.cg.bean.Bank;

public interface IBankDao {

	public Bank checkAccount(long accNo);

	public void setData(long accNo, Bank bean);

}

